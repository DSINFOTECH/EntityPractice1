﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace OnlineEntityFramework
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int selectIndex; 

        private void showData()
        {
            EntityDemoDatabaseEntities _obj = new EntityDemoDatabaseEntities();

            

            var query = from s in _obj.cust2 orderby s.custId select s;
            dataGridView1.DataSource = query; 
           

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            showData(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cust2 _custObje = new cust2();
            _custObje.custName = txtCustBox.Text.Trim();
            _custObje.custId = 1001;

            demo2222 _demoOBje = new demo2222();
            _demoOBje.tabName = txtCustBox.Text.Trim() ; 


            

            EntityDemoDatabaseEntities _obj = new EntityDemoDatabaseEntities();
         _obj.AddTocust2(_custObje);


         _obj.AddTodemo2222(_demoOBje); 


         _obj.AddTocust2(_custObje);
         
           _obj.SaveChanges();
           
            MessageBox.Show("Data Saved");
            
            showData(); 

        }

        private void button2_Click(object sender, EventArgs e)
        {
            EntityDemoDatabaseEntities _obj = new EntityDemoDatabaseEntities();
            
            int id = Convert.ToInt32(dataGridView1.Rows[selectIndex].Cells[0].Value);



            var deleteQuery = (from s in _obj.cust2 where s.custId == id select s).First();


            _obj.Attach(deleteQuery);

            _obj.DeleteObject(deleteQuery);


            _obj.SaveChanges();

            MessageBox.Show("Data Delete");
            showData(); 



        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            selectIndex = e.RowIndex; 
        }







    }
}
